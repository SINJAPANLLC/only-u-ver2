var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// server/firebase.ts
var firebase_exports = {};
__export(firebase_exports, {
  admin: () => admin,
  auth: () => auth,
  firestore: () => firestore,
  storage: () => storage
});
import admin from "firebase-admin";
import { readFileSync, existsSync } from "fs";
import { join } from "path";
var firestore, auth, storage;
var init_firebase = __esm({
  "server/firebase.ts"() {
    "use strict";
    if (!admin.apps.length) {
      try {
        const serviceAccountPath = join(process.cwd(), "firebase-admin-key.json");
        if (existsSync(serviceAccountPath)) {
          console.log("\u{1F511} Initializing Firebase with service account key...");
          const serviceAccount = JSON.parse(readFileSync(serviceAccountPath, "utf8"));
          admin.initializeApp({
            credential: admin.credential.cert(serviceAccount),
            storageBucket: "onlyu1020-c6696.firebasestorage.app"
          });
          console.log("\u2705 Firebase initialized with service account");
        } else {
          console.log("\u{1F511} Initializing Firebase with default credentials...");
          admin.initializeApp({
            projectId: "onlyu1020-c6696",
            storageBucket: "onlyu1020-c6696.firebasestorage.app"
          });
          console.log("\u2705 Firebase initialized");
        }
      } catch (error) {
        console.error("\u274C Firebase initialization failed:", error);
        throw error;
      }
    }
    firestore = admin.firestore();
    auth = admin.auth();
    storage = admin.storage();
  }
});

// server/objectStorage.ts
var objectStorage_exports = {};
__export(objectStorage_exports, {
  ObjectNotFoundError: () => ObjectNotFoundError,
  ObjectStorageService: () => ObjectStorageService,
  objectStorageClient: () => objectStorageClient,
  replitClient: () => replitClient
});
import { randomUUID } from "crypto";
async function getFirebaseStorageBucket() {
  if (!firebaseStorageBucket) {
    const { storage: storage2 } = await Promise.resolve().then(() => (init_firebase(), firebase_exports));
    firebaseStorageBucket = storage2.bucket();
  }
  return firebaseStorageBucket;
}
var ObjectNotFoundError, firebaseStorageBucket, ObjectStorageService, replitClient, objectStorageClient;
var init_objectStorage = __esm({
  "server/objectStorage.ts"() {
    "use strict";
    ObjectNotFoundError = class _ObjectNotFoundError extends Error {
      constructor() {
        super("Object not found");
        this.name = "ObjectNotFoundError";
        Object.setPrototypeOf(this, _ObjectNotFoundError.prototype);
      }
    };
    firebaseStorageBucket = null;
    ObjectStorageService = class {
      constructor() {
      }
      // Upload a file to Firebase Storage
      async uploadFile(fileBuffer, fileName, userId, contentType, visibility = "public") {
        const bucket = await getFirebaseStorageBucket();
        const objectId = randomUUID();
        const extension = fileName.split(".").pop();
        const folderPath = visibility === "public" ? "public" : "private";
        const fullStoragePath = `${folderPath}/${objectId}.${extension}`;
        console.log("[uploadFile] Uploading to Firebase Storage:", fullStoragePath);
        try {
          const file = bucket.file(fullStoragePath);
          await file.save(fileBuffer, {
            contentType: contentType || "application/octet-stream",
            metadata: {
              metadata: {
                uploadedBy: userId,
                visibility
              }
            }
          });
          if (visibility === "public") {
            await file.makePublic();
          }
          console.log("[uploadFile] Upload successful to Firebase Storage!");
        } catch (error) {
          console.error("[uploadFile] Failed to upload to Firebase Storage:", error);
          throw new Error(`Failed to upload file: ${error instanceof Error ? error.message : "Unknown error"}`);
        }
        const entityPath = `/objects/${objectId}.${extension}`;
        return {
          objectPath: entityPath,
          storageUri: fullStoragePath
        };
      }
      // Download file from Firebase Storage
      async downloadObject(filePath, res, cacheTtlSec = 3600) {
        try {
          const bucket = await getFirebaseStorageBucket();
          console.log("[downloadObject] Downloading file from Firebase:", filePath);
          const file = bucket.file(filePath);
          const [exists] = await file.exists();
          if (!exists) {
            throw new Error("File not found");
          }
          const [fileBuffer] = await file.download();
          console.log("[downloadObject] Downloaded successfully, size:", fileBuffer.length, "bytes");
          const filename = filePath.split("/").pop() || "";
          const ext = filename.toLowerCase().split(".").pop();
          let contentType = "application/octet-stream";
          if (ext === "mov" || ext === "mp4") contentType = "video/quicktime";
          else if (ext === "webm") contentType = "video/webm";
          else if (ext === "jpg" || ext === "jpeg") contentType = "image/jpeg";
          else if (ext === "png") contentType = "image/png";
          res.set({
            "Content-Type": contentType,
            "Content-Length": fileBuffer.length.toString(),
            "Cache-Control": `public, max-age=${cacheTtlSec}`,
            "Accept-Ranges": "bytes"
          });
          res.send(fileBuffer);
        } catch (error) {
          console.error("Error downloading file from Firebase:", error);
          if (!res.headersSent) {
            res.status(500).json({ error: "Error downloading file" });
          }
        }
      }
      // Get object entity file path
      async getObjectEntityFile(objectPath) {
        if (!objectPath.startsWith("/objects/")) {
          throw new ObjectNotFoundError();
        }
        const parts = objectPath.slice(1).split("/");
        if (parts.length < 2) {
          throw new ObjectNotFoundError();
        }
        const entityId = parts.slice(1).join("/");
        console.log("[getObjectEntityFile] entityId:", entityId);
        const bucket = await getFirebaseStorageBucket();
        const publicPath = `public/${entityId}`;
        const publicFile = bucket.file(publicPath);
        const [publicExists] = await publicFile.exists();
        if (publicExists) {
          return publicPath;
        }
        const privatePath = `private/${entityId}`;
        const privateFile = bucket.file(privatePath);
        const [privateExists] = await privateFile.exists();
        if (privateExists) {
          return privatePath;
        }
        throw new ObjectNotFoundError();
      }
      async normalizeObjectEntityPath(rawPath) {
        if (rawPath.startsWith("https://firebasestorage.googleapis.com/") || rawPath.startsWith("https://storage.googleapis.com/")) {
          try {
            const url = new URL(rawPath);
            const pathMatch = url.pathname.match(/\/v0\/b\/[^/]+\/o\/(.+)$/);
            if (pathMatch) {
              const decodedPath = decodeURIComponent(pathMatch[1]);
              const objectId = decodedPath.split("/").pop();
              return `/objects/${objectId}`;
            }
          } catch (error) {
            console.error("[normalizeObjectEntityPath] Failed to parse URL:", error);
          }
        }
        if (rawPath.startsWith("/objects/")) {
          return rawPath;
        }
        return rawPath;
      }
      async trySetObjectEntityAclPolicy(rawPath, aclPolicy) {
        return await this.normalizeObjectEntityPath(rawPath);
      }
      async canAccessObjectEntity(params) {
        return true;
      }
      async searchPublicObject(filePath) {
        const bucket = await getFirebaseStorageBucket();
        const fullPath = `public/${filePath}`;
        const file = bucket.file(fullPath);
        const [exists] = await file.exists();
        return exists ? fullPath : null;
      }
      async getPublicObjectSearchPaths() {
        return ["public"];
      }
      async getPrivateObjectDir() {
        return "private";
      }
    };
    replitClient = null;
    objectStorageClient = null;
  }
});

// server/index.ts
import express3 from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import cookieParser from "cookie-parser";

// server/routes.ts
init_objectStorage();
import { createServer } from "http";
import express from "express";
import Stripe from "stripe";
import crypto from "crypto";
import multer from "multer";
var stripe = process.env.STRIPE_SECRET_KEY ? new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2025-09-30.clover"
}) : null;
if (!process.env.SESSION_SECRET) {
  throw new Error("Missing required environment variable: SESSION_SECRET. Admin authentication requires this for secure token signing.");
}
var SESSION_SECRET = process.env.SESSION_SECRET;
async function registerRoutes(app2) {
  app2.use(express.json());
  app2.get("/api/health", (_req, res) => {
    res.json({ status: "ok", message: "Server is running" });
  });
  app2.get("/api/users", async (_req, res) => {
    res.json({ message: "User routes placeholder - MongoDB connection required" });
  });
  app2.get("/api/identity", async (_req, res) => {
    res.json({ message: "Identity routes placeholder - MongoDB connection required" });
  });
  app2.get("/api/notifications", async (_req, res) => {
    try {
      const { firestore: firestore2 } = await Promise.resolve().then(() => (init_firebase(), firebase_exports));
      const notificationsSnapshot = await firestore2.collection("notifications").orderBy("createdAt", "desc").get();
      const notifications = notificationsSnapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
        createdAt: doc.data().createdAt?.toDate?.() || /* @__PURE__ */ new Date()
      }));
      res.json(notifications);
    } catch (error) {
      console.error("Error fetching notifications:", error);
      res.status(500).json({ error: "Failed to fetch notifications" });
    }
  });
  app2.get("/api/notifications/user", async (_req, res) => {
    try {
      const { firestore: firestore2 } = await Promise.resolve().then(() => (init_firebase(), firebase_exports));
      console.log("\u{1F4EC} Fetching user notifications...");
      const notificationsSnapshot = await firestore2.collection("notifications").orderBy("createdAt", "desc").limit(100).get();
      console.log(`\u{1F4E6} Found ${notificationsSnapshot.size} notifications in Firestore`);
      const userNotifications = notificationsSnapshot.docs.map((doc) => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate?.() || /* @__PURE__ */ new Date()
        };
      }).filter(
        (notification) => notification.target === "all" || notification.target === "users"
      ).slice(0, 50);
      console.log(`\u2705 Returning ${userNotifications.length} user notifications`);
      res.json(userNotifications);
    } catch (error) {
      console.error("\u274C Error fetching user notifications:", error);
      if (error instanceof Error) {
        console.error("Error details:", error.message);
        console.error("Error stack:", error.stack);
      }
      res.json([]);
    }
  });
  app2.post("/api/notifications", async (req, res) => {
    try {
      console.log("\u{1F4EC} Creating notification with data:", req.body);
      const { type, title, message, target, priority, category } = req.body;
      if (!title || !message) {
        console.error("\u274C Missing required fields:", { title, message });
        return res.status(400).json({ error: "Title and message are required" });
      }
      const { firestore: firestore2, admin: admin2 } = await Promise.resolve().then(() => (init_firebase(), firebase_exports));
      const newNotification = {
        type: type || "system",
        title,
        message,
        target: target || "all",
        priority: priority || "medium",
        category: category || "admin",
        status: "sent",
        createdAt: admin2.firestore.FieldValue.serverTimestamp(),
        sentAt: admin2.firestore.FieldValue.serverTimestamp(),
        readBy: [],
        // 既読ユーザーのID配列
        readCount: 0
      };
      console.log("\u{1F4BE} Attempting to save notification to Firestore:", newNotification);
      const docRef = await firestore2.collection("notifications").add(newNotification);
      console.log("\u2705 Notification saved with ID:", docRef.id);
      const createdDoc = await docRef.get();
      const createdNotification = {
        id: docRef.id,
        ...createdDoc.data(),
        createdAt: /* @__PURE__ */ new Date()
      };
      console.log("\u{1F4E4} Returning notification:", createdNotification);
      res.status(201).json(createdNotification);
    } catch (error) {
      console.error("\u274C Error creating notification:", error);
      if (error instanceof Error) {
        console.error("Error stack:", error.stack);
        res.status(500).json({ error: "Failed to create notification", details: error.message });
      } else {
        res.status(500).json({ error: "Failed to create notification", details: String(error) });
      }
    }
  });
  app2.delete("/api/notifications/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const { firestore: firestore2 } = await Promise.resolve().then(() => (init_firebase(), firebase_exports));
      await firestore2.collection("notifications").doc(id).delete();
      res.json({ message: "Notification deleted successfully" });
    } catch (error) {
      console.error("Error deleting notification:", error);
      res.status(500).json({ error: "Failed to delete notification" });
    }
  });
  app2.patch("/api/notifications/:id/read", async (req, res) => {
    try {
      const { id } = req.params;
      const { userId } = req.body;
      const { firestore: firestore2, admin: admin2 } = await Promise.resolve().then(() => (init_firebase(), firebase_exports));
      const notificationRef = firestore2.collection("notifications").doc(id);
      const notificationDoc = await notificationRef.get();
      if (!notificationDoc.exists) {
        return res.status(404).json({ error: "Notification not found" });
      }
      await notificationRef.update({
        readBy: admin2.firestore.FieldValue.arrayUnion(userId || "anonymous"),
        readCount: admin2.firestore.FieldValue.increment(1)
      });
      const updatedDoc = await notificationRef.get();
      res.json({
        id: notificationRef.id,
        ...updatedDoc.data()
      });
    } catch (error) {
      console.error("Error marking notification as read:", error);
      res.status(500).json({ error: "Failed to mark notification as read" });
    }
  });
  app2.get("/api/posts", async (_req, res) => {
    try {
      const { firestore: firestore2 } = await Promise.resolve().then(() => (init_firebase(), firebase_exports));
      const postsSnapshot = await firestore2.collection("posts").orderBy("createdAt", "desc").get();
      const posts = postsSnapshot.docs.map((doc) => {
        const data = doc.data();
        return {
          id: doc.id,
          title: data.title || data.explanation || "Untitled",
          duration: data.duration || "00:00",
          thumbnail: data.files?.[0]?.url || data.thumbnailUrl || "/genre-1.png",
          userId: data.userId,
          userName: data.username || "Unknown",
          userAvatar: data.userAvatar || "/logo192.png",
          userFollowers: data.userFollowers || 0,
          likes: Array.isArray(data.likes) ? data.likes.length : data.likes || 0,
          bookmarks: data.bookmarks || 0,
          createdAt: data.createdAt?.toDate?.() || /* @__PURE__ */ new Date(),
          isNew: false
        };
      });
      res.json(posts);
    } catch (error) {
      console.error("Error fetching posts:", error);
      res.status(500).json({ error: "Failed to fetch posts" });
    }
  });
  app2.get("/api/featured-pickup", async (_req, res) => {
    try {
      const { firestore: firestore2 } = await Promise.resolve().then(() => (init_firebase(), firebase_exports));
      const pickupsSnapshot = await firestore2.collection("featuredPickups").where("isActive", "==", true).orderBy("position", "asc").get();
      if (pickupsSnapshot.empty) {
        return res.json([]);
      }
      const pickupsWithDetails = await Promise.all(
        pickupsSnapshot.docs.map(async (doc) => {
          const pickupData = doc.data();
          const postId = pickupData.postId;
          const postDoc = await firestore2.collection("posts").doc(postId).get();
          if (!postDoc.exists) {
            return null;
          }
          const postData = postDoc.data();
          if (!postData) {
            return null;
          }
          return {
            id: doc.id,
            postId: pickupData.postId,
            position: pickupData.position,
            createdAt: pickupData.createdAt,
            addedBy: pickupData.addedBy,
            post: {
              id: postDoc.id,
              title: postData.title || postData.explanation || "Untitled",
              duration: postData.duration || "00:00",
              thumbnail: postData.thumbnailUrl || postData.files?.[0]?.thumbnailUrl || "/genre-1.png",
              userId: postData.userId,
              userName: postData.userName || "Anonymous",
              userAvatar: postData.userAvatar || "/logo192.png",
              userFollowers: postData.userFollowers || 0,
              likes: postData.likes || 0,
              bookmarks: postData.bookmarks || 0,
              createdAt: postData.createdAt,
              isNew: postData.isNew !== false
            }
          };
        })
      );
      const validPickups = pickupsWithDetails.filter((item) => item !== null);
      res.json(validPickups);
    } catch (error) {
      console.error("Error fetching featured pickups:", error);
      res.status(500).json({ error: "Failed to fetch featured pickups" });
    }
  });
  app2.post("/api/featured-pickup", async (req, res) => {
    try {
      const { firestore: firestore2 } = await Promise.resolve().then(() => (init_firebase(), firebase_exports));
      const { postId, position } = req.body;
      if (!postId) {
        return res.status(400).json({ error: "Post ID is required" });
      }
      const postDoc = await firestore2.collection("posts").doc(postId).get();
      if (!postDoc.exists) {
        return res.status(404).json({ error: "Post not found" });
      }
      const existingPickup = await firestore2.collection("featuredPickups").where("postId", "==", postId).where("isActive", "==", true).get();
      if (!existingPickup.empty) {
        return res.status(400).json({ error: "Post already in featured pickup" });
      }
      const pickupsSnapshot = await firestore2.collection("featuredPickups").where("isActive", "==", true).orderBy("position", "desc").limit(1).get();
      const maxPosition = pickupsSnapshot.empty ? 0 : pickupsSnapshot.docs[0].data().position;
      const newPickup = {
        postId,
        position: position || maxPosition + 1,
        createdAt: /* @__PURE__ */ new Date(),
        addedBy: "admin",
        isActive: true
      };
      const docRef = await firestore2.collection("featuredPickups").add(newPickup);
      res.status(201).json({ id: docRef.id, ...newPickup });
    } catch (error) {
      console.error("Error adding featured pickup:", error);
      res.status(500).json({ error: "Failed to add featured pickup" });
    }
  });
  app2.patch("/api/featured-pickup/:id", async (req, res) => {
    try {
      const { firestore: firestore2 } = await Promise.resolve().then(() => (init_firebase(), firebase_exports));
      const { id } = req.params;
      const { position } = req.body;
      const pickupRef = firestore2.collection("featuredPickups").doc(id);
      const pickupDoc = await pickupRef.get();
      if (!pickupDoc.exists) {
        return res.status(404).json({ error: "Featured pickup not found" });
      }
      const updateData = {};
      if (position !== void 0) {
        updateData.position = position;
      }
      await pickupRef.update(updateData);
      const updatedDoc = await pickupRef.get();
      res.json({ id: updatedDoc.id, ...updatedDoc.data() });
    } catch (error) {
      console.error("Error updating featured pickup:", error);
      res.status(500).json({ error: "Failed to update featured pickup" });
    }
  });
  app2.patch("/api/featured-pickup/reorder", async (req, res) => {
    try {
      const { firestore: firestore2 } = await Promise.resolve().then(() => (init_firebase(), firebase_exports));
      const { pickupIds } = req.body;
      if (!Array.isArray(pickupIds)) {
        return res.status(400).json({ error: "pickupIds must be an array" });
      }
      const batch = firestore2.batch();
      pickupIds.forEach((id, index) => {
        const pickupRef = firestore2.collection("featuredPickups").doc(id);
        batch.update(pickupRef, { position: index + 1 });
      });
      await batch.commit();
      const pickupsSnapshot = await firestore2.collection("featuredPickups").where("isActive", "==", true).orderBy("position", "asc").get();
      const pickups = pickupsSnapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data()
      }));
      res.json(pickups);
    } catch (error) {
      console.error("Error reordering featured pickups:", error);
      res.status(500).json({ error: "Failed to reorder featured pickups" });
    }
  });
  app2.delete("/api/featured-pickup/:id", async (req, res) => {
    try {
      const { firestore: firestore2 } = await Promise.resolve().then(() => (init_firebase(), firebase_exports));
      const { id } = req.params;
      const pickupRef = firestore2.collection("featuredPickups").doc(id);
      const pickupDoc = await pickupRef.get();
      if (!pickupDoc.exists) {
        return res.status(404).json({ error: "Featured pickup not found" });
      }
      await pickupRef.update({ isActive: false });
      res.json({ message: "Featured pickup deleted successfully" });
    } catch (error) {
      console.error("Error deleting featured pickup:", error);
      res.status(500).json({ error: "Failed to delete featured pickup" });
    }
  });
  app2.get("/api/featured-creators", async (_req, res) => {
    try {
      const { firestore: firestore2 } = await Promise.resolve().then(() => (init_firebase(), firebase_exports));
      const creatorsSnapshot = await firestore2.collection("featuredCreators").where("isActive", "==", true).orderBy("position", "asc").get();
      if (creatorsSnapshot.empty) {
        return res.json([]);
      }
      const creatorsWithDetails = await Promise.all(
        creatorsSnapshot.docs.map(async (doc) => {
          const creatorData = doc.data();
          const userId = creatorData.userId;
          const userDoc = await firestore2.collection("users").doc(userId).get();
          if (!userDoc.exists) {
            return null;
          }
          const userData = userDoc.data();
          if (!userData) {
            return null;
          }
          return {
            id: doc.id,
            userId: creatorData.userId,
            position: creatorData.position,
            createdAt: creatorData.createdAt,
            addedBy: creatorData.addedBy,
            user: {
              id: userDoc.id,
              name: userData.displayName || userData.username || "Anonymous",
              avatar: userData.photoURL || "/logo192.png",
              followers: userData.followerCount || 0,
              likes: userData.totalLikes || 0,
              isVerified: userData.isVerified || false
            }
          };
        })
      );
      const validCreators = creatorsWithDetails.filter((item) => item !== null);
      res.json(validCreators);
    } catch (error) {
      console.error("Error fetching featured creators:", error);
      res.status(500).json({ error: "Failed to fetch featured creators" });
    }
  });
  app2.post("/api/featured-creators", async (req, res) => {
    try {
      const { firestore: firestore2 } = await Promise.resolve().then(() => (init_firebase(), firebase_exports));
      const { userId, position } = req.body;
      if (!userId) {
        return res.status(400).json({ error: "User ID is required" });
      }
      const userDoc = await firestore2.collection("users").doc(userId).get();
      if (!userDoc.exists) {
        return res.status(404).json({ error: "User not found" });
      }
      const existingCreator = await firestore2.collection("featuredCreators").where("userId", "==", userId).where("isActive", "==", true).get();
      if (!existingCreator.empty) {
        return res.status(400).json({ error: "Creator already in featured list" });
      }
      const creatorsSnapshot = await firestore2.collection("featuredCreators").where("isActive", "==", true).orderBy("position", "desc").limit(1).get();
      const maxPosition = creatorsSnapshot.empty ? 0 : creatorsSnapshot.docs[0].data().position;
      const newCreator = {
        userId,
        position: position || maxPosition + 1,
        createdAt: /* @__PURE__ */ new Date(),
        addedBy: "admin",
        isActive: true
      };
      const docRef = await firestore2.collection("featuredCreators").add(newCreator);
      res.status(201).json({ id: docRef.id, ...newCreator });
    } catch (error) {
      console.error("Error adding featured creator:", error);
      res.status(500).json({ error: "Failed to add featured creator" });
    }
  });
  app2.patch("/api/featured-creators/:id", async (req, res) => {
    try {
      const { firestore: firestore2 } = await Promise.resolve().then(() => (init_firebase(), firebase_exports));
      const { id } = req.params;
      const { position } = req.body;
      const creatorRef = firestore2.collection("featuredCreators").doc(id);
      const creatorDoc = await creatorRef.get();
      if (!creatorDoc.exists) {
        return res.status(404).json({ error: "Featured creator not found" });
      }
      const updateData = {};
      if (position !== void 0) {
        updateData.position = position;
      }
      await creatorRef.update(updateData);
      const updatedDoc = await creatorRef.get();
      res.json({ id: updatedDoc.id, ...updatedDoc.data() });
    } catch (error) {
      console.error("Error updating featured creator:", error);
      res.status(500).json({ error: "Failed to update featured creator" });
    }
  });
  app2.delete("/api/featured-creators/:id", async (req, res) => {
    try {
      const { firestore: firestore2 } = await Promise.resolve().then(() => (init_firebase(), firebase_exports));
      const { id } = req.params;
      const creatorRef = firestore2.collection("featuredCreators").doc(id);
      const creatorDoc = await creatorRef.get();
      if (!creatorDoc.exists) {
        return res.status(404).json({ error: "Featured creator not found" });
      }
      await creatorRef.update({ isActive: false });
      res.json({ message: "Featured creator deleted successfully" });
    } catch (error) {
      console.error("Error deleting featured creator:", error);
      res.status(500).json({ error: "Failed to delete featured creator" });
    }
  });
  app2.get("/public-objects/:filePath(*)", async (req, res) => {
    const filePath = req.params.filePath;
    const { ObjectStorageService: ObjectStorageService2 } = await Promise.resolve().then(() => (init_objectStorage(), objectStorage_exports));
    const objectStorageService = new ObjectStorageService2();
    try {
      const file = await objectStorageService.searchPublicObject(filePath);
      if (!file) {
        return res.status(404).json({ error: "File not found" });
      }
      objectStorageService.downloadObject(file, res);
    } catch (error) {
      console.error("Error searching for public object:", error);
      return res.status(500).json({ error: "Internal server error" });
    }
  });
  app2.get("/objects/:objectPath(*)", async (req, res) => {
    const { ObjectStorageService: ObjectStorageService2, ObjectNotFoundError: ObjectNotFoundError2 } = await Promise.resolve().then(() => (init_objectStorage(), objectStorage_exports));
    const objectStorageService = new ObjectStorageService2();
    try {
      const objectFile = await objectStorageService.getObjectEntityFile(req.path);
      objectStorageService.downloadObject(objectFile, res);
    } catch (error) {
      console.error("Error serving object:", error);
      if (error instanceof ObjectNotFoundError2) {
        return res.sendStatus(404);
      }
      return res.sendStatus(500);
    }
  });
  class AuthenticationError extends Error {
    constructor(message) {
      super(message);
      this.name = "AuthenticationError";
    }
  }
  async function verifyFirebaseToken(authHeader) {
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      throw new AuthenticationError("Missing or invalid authorization header");
    }
    const token = authHeader.substring(7);
    try {
      const { auth: auth2 } = await Promise.resolve().then(() => (init_firebase(), firebase_exports));
      const decodedToken = await auth2.verifyIdToken(token);
      return decodedToken.uid;
    } catch (error) {
      console.error("Firebase token verification failed:", error);
      throw new AuthenticationError("Invalid authentication token");
    }
  }
  const upload = multer({
    storage: multer.memoryStorage(),
    limits: {
      fileSize: 500 * 1024 * 1024
      // 500MB limit for videos
    }
  });
  app2.post("/api/objects/upload", upload.single("file"), async (req, res) => {
    try {
      const userId = await verifyFirebaseToken(req.headers.authorization);
      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
      }
      const allowedMimeTypes = [
        "image/jpeg",
        "image/jpg",
        "image/png",
        "image/gif",
        "image/webp",
        "video/mp4",
        "video/quicktime",
        "video/webm",
        "video/avi",
        "video/mov"
      ];
      if (!allowedMimeTypes.includes(req.file.mimetype)) {
        return res.status(400).json({
          error: "Invalid file type. Only images and videos are allowed."
        });
      }
      const { ObjectStorageService: ObjectStorageService2 } = await Promise.resolve().then(() => (init_objectStorage(), objectStorage_exports));
      const objectStorageService = new ObjectStorageService2();
      const { visibility = "public" } = req.body;
      const uploadResult = await objectStorageService.uploadFile(
        req.file.buffer,
        req.file.originalname,
        userId,
        req.file.mimetype,
        visibility
      );
      res.json({
        objectPath: uploadResult.objectPath,
        storageUri: uploadResult.storageUri,
        fileName: req.file.originalname,
        contentType: req.file.mimetype,
        size: req.file.size
      });
    } catch (error) {
      console.error("Error uploading file:", error);
      if (error instanceof AuthenticationError) {
        return res.status(401).json({ error: error.message });
      }
      res.status(500).json({ error: "Internal server error" });
    }
  });
  app2.put("/api/content/upload-complete", async (req, res) => {
    if (!req.body.contentURL) {
      return res.status(400).json({ error: "contentURL is required" });
    }
    try {
      const userId = await verifyFirebaseToken(req.headers.authorization);
      const { ObjectStorageService: ObjectStorageService2 } = await Promise.resolve().then(() => (init_objectStorage(), objectStorage_exports));
      const objectStorageService = new ObjectStorageService2();
      const { visibility = "public", contentType, title, postId, aclRules } = req.body;
      let objectPath;
      let storagePath;
      try {
        objectPath = await objectStorageService.trySetObjectEntityAclPolicy(
          req.body.contentURL,
          {
            owner: userId,
            visibility,
            aclRules: aclRules || void 0
          }
        );
        const objectFilePath = await objectStorageService.getObjectEntityFile(objectPath);
        const { storage: storage2 } = await Promise.resolve().then(() => (init_firebase(), firebase_exports));
        const bucket = storage2.bucket();
        storagePath = `gs://${bucket.name}/${objectFilePath}`;
      } catch (aclError) {
        console.error("Warning: ACL setting failed, using URL as-is:", aclError);
        objectPath = await objectStorageService.normalizeObjectEntityPath(req.body.contentURL);
        storagePath = req.body.contentURL;
      }
      const { firestore: firestore2, admin: admin2 } = await Promise.resolve().then(() => (init_firebase(), firebase_exports));
      const contentMetadata = {
        objectPath,
        // Normalized path: /objects/<uuid>.<ext>
        storagePath,
        // Actual GCS path: gs://bucket/path or URL
        contentType,
        title: title || "Untitled",
        owner: userId,
        visibility,
        uploadedAt: admin2.firestore.FieldValue.serverTimestamp(),
        postId: postId || null
      };
      let contentDoc;
      try {
        contentDoc = await firestore2.collection("content_uploads").add(contentMetadata);
      } catch (firestoreError) {
        console.error("Firestore save error:", firestoreError);
        return res.status(200).json({
          objectPath,
          contentId: null,
          message: "Content uploaded successfully (metadata save pending)",
          warning: "Metadata not saved to database"
        });
      }
      res.status(200).json({
        objectPath,
        contentId: contentDoc.id,
        message: "Content uploaded and metadata saved successfully"
      });
    } catch (error) {
      console.error("Error in upload-complete:", error);
      if (error instanceof AuthenticationError) {
        return res.status(401).json({ error: error.message });
      }
      res.status(500).json({ error: "Internal server error" });
    }
  });
  app2.post("/api/create-payment-intent", async (req, res) => {
    try {
      const { amount, currency = "jpy", planId, planName } = req.body;
      if (!amount || amount <= 0) {
        return res.status(400).json({ error: "Invalid amount" });
      }
      if (amount > 1e5) {
        return res.status(400).json({ error: "Amount exceeds maximum limit" });
      }
      if (currency && currency !== "jpy") {
        return res.status(400).json({ error: "Only JPY currency is supported" });
      }
      if (!stripe) {
        return res.status(500).json({ error: "Payment system not configured" });
      }
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(amount),
        // Amount in yen (no need to multiply by 100 for JPY)
        currency,
        metadata: {
          planId: planId || "",
          planName: planName || ""
        },
        automatic_payment_methods: {
          enabled: true
        }
      });
      res.json({ clientSecret: paymentIntent.client_secret });
    } catch (error) {
      console.error("Error creating payment intent:", error);
      res.status(500).json({ error: "Error creating payment intent: " + error.message });
    }
  });
  function generateSecureSessionToken(email) {
    const timestamp = Date.now();
    const payload = `${email}:${timestamp}`;
    const signature = crypto.createHmac("sha256", SESSION_SECRET).update(payload).digest("hex");
    return Buffer.from(`${payload}:${signature}`).toString("base64");
  }
  function verifySecureSessionToken(token) {
    try {
      const decoded = Buffer.from(token, "base64").toString("utf-8");
      const parts = decoded.split(":");
      if (parts.length !== 3) return null;
      const [email, timestampStr, signature] = parts;
      const timestamp = parseInt(timestampStr);
      const payload = `${email}:${timestamp}`;
      const expectedSignature = crypto.createHmac("sha256", SESSION_SECRET).update(payload).digest("hex");
      if (signature !== expectedSignature) {
        return null;
      }
      const tokenAge = Date.now() - timestamp;
      if (tokenAge > 24 * 60 * 60 * 1e3) {
        return null;
      }
      return { email, timestamp };
    } catch {
      return null;
    }
  }
  app2.post("/api/admin/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      if (!email || !password) {
        return res.status(400).json({ error: "Email and password are required" });
      }
      const adminEmail = process.env.ADMIN_EMAIL || "info@sinjapan.jp";
      const adminPassword = process.env.ADMIN_PASSWORD || "Kazuya8008";
      if (email === adminEmail && password === adminPassword) {
        const sessionToken = generateSecureSessionToken(email);
        res.cookie("adminSession", sessionToken, {
          httpOnly: true,
          // Not accessible via JavaScript
          secure: process.env.NODE_ENV === "production",
          // HTTPS only in production
          sameSite: "strict",
          // CSRF protection
          maxAge: 24 * 60 * 60 * 1e3
          // 24 hours
        });
        res.json({
          success: true,
          email,
          expiresIn: 24 * 60 * 60 * 1e3
          // 24 hours in milliseconds
        });
      } else {
        res.status(401).json({ error: "Invalid credentials" });
      }
    } catch (error) {
      console.error("Error during admin login:", error);
      res.status(500).json({ error: "Login error: " + error.message });
    }
  });
  async function verifyAdminToken(req, res, next) {
    try {
      const token = req.cookies?.adminSession;
      if (!token) {
        return res.status(401).json({ error: "No session found" });
      }
      const verifiedSession = verifySecureSessionToken(token);
      if (!verifiedSession) {
        res.clearCookie("adminSession");
        return res.status(401).json({ error: "Invalid or expired session" });
      }
      const adminEmail = process.env.ADMIN_EMAIL || "info@sinjapan.jp";
      if (verifiedSession.email !== adminEmail) {
        res.clearCookie("adminSession");
        return res.status(403).json({ error: "Unauthorized" });
      }
      req.adminEmail = verifiedSession.email;
      next();
    } catch (error) {
      res.clearCookie("adminSession");
      return res.status(401).json({ error: "Invalid session token" });
    }
  }
  app2.get("/api/admin/verify", verifyAdminToken, (req, res) => {
    res.json({ success: true, email: req.adminEmail });
  });
  app2.post("/api/admin/logout", (req, res) => {
    res.clearCookie("adminSession");
    res.json({ success: true });
  });
  app2.post("/api/admin/create-user", verifyAdminToken, async (req, res) => {
    try {
      const { email, password, displayName } = req.body;
      if (!email || !password || !displayName) {
        return res.status(400).json({ error: "Email, password, and displayName are required" });
      }
      const { auth: auth2, firestore: firestore2, admin: admin2 } = await Promise.resolve().then(() => (init_firebase(), firebase_exports));
      const userRecord = await auth2.createUser({
        email,
        password,
        displayName,
        emailVerified: false
      });
      console.log("User created in Firebase Auth:", userRecord.uid);
      await firestore2.collection("users").doc(userRecord.uid).set({
        displayName,
        email,
        photoURL: null,
        createdAt: admin2.firestore.FieldValue.serverTimestamp(),
        lastSeen: admin2.firestore.FieldValue.serverTimestamp(),
        isOnline: false,
        provider: "email",
        stats: {
          posts: 0,
          likes: 0,
          followers: 0,
          following: 0
        },
        bio: "",
        coverImage: null,
        isVerified: false,
        subscriptionPlans: []
      });
      console.log("User profile created in Firestore");
      res.json({
        success: true,
        userId: userRecord.uid,
        email: userRecord.email,
        displayName: userRecord.displayName
      });
    } catch (error) {
      console.error("Error creating user:", error);
      res.status(500).json({ error: "Error creating user: " + error.message });
    }
  });
  app2.post("/api/upload-slider-image", express.raw({ type: "application/octet-stream", limit: "10mb" }), async (req, res) => {
    try {
      const multer2 = await import("multer");
      const storage2 = multer2.default.memoryStorage();
      const upload2 = multer2.default({ storage: storage2 }).single("file");
      upload2(req, res, async (err) => {
        if (err) {
          return res.status(400).json({ error: "File upload failed" });
        }
        const file = req.file;
        if (!file) {
          return res.status(400).json({ error: "No file provided" });
        }
        const { ObjectStorageService: ObjectStorageService2 } = await Promise.resolve().then(() => (init_objectStorage(), objectStorage_exports));
        const { storage: firebaseStorage } = await Promise.resolve().then(() => (init_firebase(), firebase_exports));
        const objectStorageService = new ObjectStorageService2();
        const { randomUUID: randomUUID2 } = await import("crypto");
        const fileId = randomUUID2();
        const extension = file.mimetype.split("/")[1];
        const fileName = `slider-${fileId}.${extension}`;
        const bucket = firebaseStorage.bucket();
        const blob = bucket.file(`public/${fileName}`);
        const blobStream = blob.createWriteStream({
          resumable: false,
          metadata: {
            contentType: file.mimetype
          }
        });
        blobStream.on("error", (error) => {
          console.error("Upload error:", error);
          res.status(500).json({ error: "Error uploading file" });
        });
        blobStream.on("finish", async () => {
          await blob.makePublic();
          const imageUrl = `https://storage.googleapis.com/${bucket.name}/${blob.name}`;
          res.json({ imageUrl });
        });
        blobStream.end(file.buffer);
      });
    } catch (error) {
      console.error("Error in upload endpoint:", error);
      res.status(500).json({ error: "Error uploading image: " + error.message });
    }
  });
  app2.post("/api/create-subscription-checkout", async (req, res) => {
    try {
      const { planId, planTitle, planPrice, creatorId, creatorName } = req.body;
      if (!planId || !planTitle || !planPrice || !creatorId) {
        return res.status(400).json({ error: "Missing required fields" });
      }
      const priceMatch = planPrice.match(/\d+/);
      if (!priceMatch) {
        return res.status(400).json({ error: "Invalid price format" });
      }
      const basePrice = parseInt(priceMatch[0]);
      const tax = Math.floor(basePrice * 0.1);
      const platformFee = Math.floor(basePrice * 0.1);
      const amount = basePrice + tax + platformFee;
      if (!stripe) {
        return res.status(500).json({ error: "Payment system not configured" });
      }
      const session = await stripe.checkout.sessions.create({
        payment_method_types: ["card"],
        line_items: [
          {
            price_data: {
              currency: "jpy",
              product_data: {
                name: `${creatorName} - ${planTitle}`,
                description: `\u6708\u984D\u30B5\u30D6\u30B9\u30AF\u30EA\u30D7\u30B7\u30E7\u30F3\u30D7\u30E9\u30F3`
              },
              unit_amount: amount,
              recurring: {
                interval: "month"
              }
            },
            quantity: 1
          }
        ],
        mode: "subscription",
        success_url: `${req.headers.origin}/profile/${creatorId}?subscription=success&plan=${planId}`,
        cancel_url: `${req.headers.origin}/profile/${creatorId}?subscription=cancelled`,
        metadata: {
          planId,
          creatorId
        }
      });
      res.json({ sessionId: session.id, url: session.url });
    } catch (error) {
      console.error("Error creating checkout session:", error);
      res.status(500).json({ error: "Error creating checkout session: " + error.message });
    }
  });
  app2.post("/api/create-subscription-payment-intent", async (req, res) => {
    try {
      const { planId, planTitle, planPrice, creatorId, creatorName } = req.body;
      if (!planId || !planTitle || !planPrice || !creatorId) {
        return res.status(400).json({ error: "Missing required fields" });
      }
      const cleanPrice = planPrice.replace(/[^\d]/g, "");
      if (!cleanPrice) {
        return res.status(400).json({ error: "Invalid price format" });
      }
      const basePrice = parseInt(cleanPrice);
      const platformFee = Math.floor(basePrice * 0.1);
      const tax = Math.floor(basePrice * 0.1);
      const totalAmount = basePrice + platformFee + tax;
      const amount = totalAmount;
      if (!stripe) {
        return res.status(500).json({ error: "Payment system not configured" });
      }
      const paymentIntent = await stripe.paymentIntents.create({
        amount,
        currency: "jpy",
        automatic_payment_methods: {
          enabled: true
        },
        metadata: {
          planId,
          planTitle,
          creatorId,
          creatorName,
          basePrice: basePrice.toString(),
          tax: tax.toString(),
          platformFee: platformFee.toString()
        }
      });
      res.json({ clientSecret: paymentIntent.client_secret });
    } catch (error) {
      console.error("Error creating payment intent:", error);
      res.status(500).json({ error: "Error creating payment intent: " + error.message });
    }
  });
  app2.post("/api/upload", upload.single("file"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
      }
      const userId = await verifyFirebaseToken(req.headers.authorization);
      const folder = req.body.folder || req.query.folder || ".private";
      const visibility = folder === ".private" ? "private" : "public";
      console.log(`\u{1F4C1} Upload folder: ${folder}, visibility: ${visibility}, user: ${userId}`);
      const objectStorageService = new ObjectStorageService();
      const uploadResult = await objectStorageService.uploadFile(
        req.file.buffer,
        req.file.originalname,
        userId,
        req.file.mimetype,
        visibility
      );
      console.log("[Upload] Uploaded to:", uploadResult.storageUri);
      res.json({
        url: uploadResult.objectPath,
        fileName: req.file.originalname,
        size: req.file.size,
        type: req.file.mimetype
      });
    } catch (error) {
      console.error("Error uploading file:", error);
      if (error instanceof AuthenticationError) {
        return res.status(401).json({ error: error.message });
      }
      res.status(500).json({ error: "Failed to upload file: " + error.message });
    }
  });
  app2.get("/api/proxy/:folder/:filename", async (req, res) => {
    try {
      const { folder, filename } = req.params;
      const objectPath = `/objects/${filename}`;
      console.log("Proxy request for:", folder, filename, "Object path:", objectPath, "Range:", req.headers.range);
      const { ObjectStorageService: ObjectStorageService2 } = await Promise.resolve().then(() => (init_objectStorage(), objectStorage_exports));
      const { storage: storage2 } = await Promise.resolve().then(() => (init_firebase(), firebase_exports));
      const objectStorageService = new ObjectStorageService2();
      const filePath = await objectStorageService.getObjectEntityFile(objectPath);
      console.log("[Proxy] Downloading file from Firebase Storage:", filePath);
      const bucket = storage2.bucket();
      const file = bucket.file(filePath);
      const [fileBuffer] = await file.download();
      if (!fileBuffer || fileBuffer.length === 0) {
        return res.status(404).json({ error: "File not found" });
      }
      console.log("[Proxy] Downloaded successfully, size:", fileBuffer.length, "bytes");
      const ext = filename.toLowerCase().split(".").pop();
      let contentType = "application/octet-stream";
      if (ext === "mp4") contentType = "video/mp4";
      else if (ext === "mov") contentType = "video/quicktime";
      else if (ext === "webm") contentType = "video/webm";
      else if (ext === "jpg" || ext === "jpeg") contentType = "image/jpeg";
      else if (ext === "png") contentType = "image/png";
      else if (ext === "gif") contentType = "image/gif";
      else if (ext === "webp") contentType = "image/webp";
      const fileSize = fileBuffer.length;
      const range = req.headers.range;
      if (range) {
        const parts = range.replace(/bytes=/, "").split("-");
        const start = parseInt(parts[0], 10);
        const end = parts[1] ? parseInt(parts[1], 10) : fileSize - 1;
        const chunkSize = end - start + 1;
        res.writeHead(206, {
          "Content-Range": `bytes ${start}-${end}/${fileSize}`,
          "Accept-Ranges": "bytes",
          "Content-Length": chunkSize,
          "Content-Type": contentType,
          "Cache-Control": "public, max-age=31536000"
        });
        res.end(fileBuffer.slice(start, end + 1));
      } else {
        res.writeHead(200, {
          "Content-Length": fileSize,
          "Content-Type": contentType,
          "Accept-Ranges": "bytes",
          "Cache-Control": "public, max-age=31536000"
        });
        res.end(fileBuffer);
      }
    } catch (error) {
      console.error("Error proxying file:", error);
      if (res.headersSent) {
        return;
      }
      const { filename } = req.params;
      if (filename.match(/\.(png|jpg|jpeg|gif)$/i)) {
        console.log(`\u26A0\uFE0F Image not found, redirecting to default avatar`);
        const defaultAvatar = "https://api.dicebear.com/7.x/avataaars/svg?seed=" + filename;
        return res.redirect(defaultAvatar);
      }
      res.status(404).json({ error: "File not found" });
    }
  });
  const httpServer = createServer(app2);
  return httpServer;
}

// server/vite.ts
import express2 from "express";
import fs from "fs";
import path2 from "path";
import { createServer as createViteServer, createLogger } from "vite";

// vite.config.ts
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path from "path";
import runtimeErrorOverlay from "@replit/vite-plugin-runtime-error-modal";
var vite_config_default = defineConfig({
  plugins: [
    react(),
    runtimeErrorOverlay(),
    ...process.env.NODE_ENV !== "production" && process.env.REPL_ID !== void 0 ? [
      await import("@replit/vite-plugin-cartographer").then(
        (m) => m.cartographer()
      ),
      await import("@replit/vite-plugin-dev-banner").then(
        (m) => m.devBanner()
      )
    ] : []
  ],
  resolve: {
    alias: {
      "@": path.resolve(import.meta.dirname, "client", "src"),
      "@shared": path.resolve(import.meta.dirname, "shared"),
      "@assets": path.resolve(import.meta.dirname, "attached_assets")
    }
  },
  root: path.resolve(import.meta.dirname, "client"),
  build: {
    outDir: path.resolve(import.meta.dirname, "dist/public"),
    emptyOutDir: true
  },
  server: {
    fs: {
      strict: true,
      deny: ["**/.*"]
    }
  }
});

// server/vite.ts
import { nanoid } from "nanoid";
var viteLogger = createLogger();
function log(message, source = "express") {
  const formattedTime = (/* @__PURE__ */ new Date()).toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true
  });
  console.log(`${formattedTime} [${source}] ${message}`);
}
async function setupVite(app2, server) {
  const serverOptions = {
    middlewareMode: true,
    hmr: { server },
    allowedHosts: true
  };
  const vite = await createViteServer({
    ...vite_config_default,
    configFile: false,
    customLogger: {
      ...viteLogger,
      error: (msg, options) => {
        viteLogger.error(msg, options);
        process.exit(1);
      }
    },
    server: serverOptions,
    appType: "custom"
  });
  app2.use(vite.middlewares);
  app2.use("*", async (req, res, next) => {
    const url = req.originalUrl;
    try {
      const clientTemplate = path2.resolve(
        import.meta.dirname,
        "..",
        "client",
        "index.html"
      );
      let template = await fs.promises.readFile(clientTemplate, "utf-8");
      template = template.replace(
        `src="/src/main.tsx"`,
        `src="/src/main.tsx?v=${nanoid()}"`
      );
      const page = await vite.transformIndexHtml(url, template);
      res.status(200).set({ "Content-Type": "text/html" }).end(page);
    } catch (e) {
      vite.ssrFixStacktrace(e);
      next(e);
    }
  });
}
function serveStatic(app2) {
  const distPath = path2.resolve(process.cwd(), "dist", "public");
  if (!fs.existsSync(distPath)) {
    throw new Error(
      `Could not find the build directory: ${distPath}, make sure to build the client first`
    );
  }
  app2.use(express2.static(distPath));
  app2.use("*", (_req, res) => {
    res.sendFile(path2.resolve(distPath, "index.html"));
  });
}

// server/index.ts
init_firebase();
admin.apps;
var app = express3();
app.set("trust proxy", 1);
app.use(cookieParser());
var isDevelopment = app.get("env") === "development";
app.use(helmet({
  contentSecurityPolicy: isDevelopment ? false : {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "https://js.stripe.com", "https://apis.google.com"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
      imgSrc: ["'self'", "data:", "https:", "blob:"],
      connectSrc: [
        "'self'",
        "https://api.stripe.com",
        "https://firestore.googleapis.com",
        "https://identitytoolkit.googleapis.com",
        "https://securetoken.googleapis.com",
        "https://*.firebaseio.com",
        "wss://*.firebaseio.com",
        "wss:"
      ],
      frameSrc: ["'self'", "https://js.stripe.com"]
    }
  },
  crossOriginEmbedderPolicy: false
}));
var apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1e3,
  // 15 minutes
  max: 100,
  // Limit each IP to 100 requests per windowMs
  message: "Too many requests from this IP, please try again later.",
  standardHeaders: true,
  legacyHeaders: false
});
var adminLimiter = rateLimit({
  windowMs: 15 * 60 * 1e3,
  // 15 minutes
  max: 10,
  // Limit each IP to 10 requests per windowMs for admin
  message: "Too many admin requests, please try again later.",
  standardHeaders: true,
  legacyHeaders: false
});
app.use("/api/", apiLimiter);
app.use("/api/admin/", adminLimiter);
app.use(express3.json({ limit: "10mb" }));
app.use(express3.urlencoded({ extended: false, limit: "10mb" }));
app.use((req, res, next) => {
  const start = Date.now();
  const path3 = req.path;
  let capturedJsonResponse = void 0;
  const originalResJson = res.json;
  res.json = function(bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };
  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path3.startsWith("/api")) {
      let logLine = `${req.method} ${path3} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }
      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "\u2026";
      }
      log(logLine);
    }
  });
  next();
});
(async () => {
  const server = await registerRoutes(app);
  app.use((err, _req, res, _next) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";
    res.status(status).json({ message });
    throw err;
  });
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }
  const port = parseInt(process.env.PORT || "5000", 10);
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true
  }, () => {
    log(`serving on port ${port}`);
  });
})();
